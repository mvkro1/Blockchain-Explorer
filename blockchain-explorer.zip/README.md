# Blockchain Explorer

A lightweight blockchain explorer for monitoring transactions, addresses, and token transfers.